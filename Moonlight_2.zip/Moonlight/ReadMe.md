[[
        • ▌ ▄ ·.              ▐ ▄ ▄▄▌  ▪   ▄▄ •  ▄ .▄▄▄▄▄▄
        ·██ ▐███▪▪     ▪     •█▌▐███•  ██ ▐█ ▀ ▪██▪▐█•██  
        ▐█ ▌▐▌▐█· ▄█▀▄  ▄█▀▄ ▐█▐▐▌██▪  ▐█·▄█ ▀█▄██▀▐█ ▐█.▪
        ██ ██▌▐█▌▐█▌.▐▌▐█▌.▐▌██▐█▌▐█▌▐▌▐█▌▐█▄▪▐███▌▐▀ ▐█▌·
        ▀▀  █▪▀▀▀ ▀█▄▀▪ ▀█▄▀▪▀▀ █▪.▀▀▀ ▀▀▀·▀▀▀▀ ▀▀▀ · ▀▀▀ 
            
                        Protected and Safe
]]


Thanks for using Moonlight Anticheat V3.3.8


Unban:

CONSOLE ONLY: moonunban [BANID]



Set the Webhooks in the config file and adjust everything. Adjust tables to.


ADMIN:

add_ace moonadmin allow 
add_ace identifier.HERETHESTEAMHEX moonadmin allow


REFRESH WITHOUT RESTART:

Current Command is "moonrefresh" if you want to change it go into the serverconfig and find MoonServer.ConfigRefreshCommand


BACKDOOR SCAN COMMAND:

backdoorscan

^^ Dont trust this to 100% because it cant find obfuscated strings

