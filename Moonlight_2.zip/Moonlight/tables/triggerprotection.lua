--[[
        • ▌ ▄ ·.              ▐ ▄ ▄▄▌  ▪   ▄▄ •  ▄ .▄▄▄▄▄▄
        ·██ ▐███▪▪     ▪     •█▌▐███•  ██ ▐█ ▀ ▪██▪▐█•██  
        ▐█ ▌▐▌▐█· ▄█▀▄  ▄█▀▄ ▐█▐▐▌██▪  ▐█·▄█ ▀█▄██▀▐█ ▐█.▪
        ██ ██▌▐█▌▐█▌.▐▌▐█▌.▐▌██▐█▌▐█▌▐▌▐█▌▐█▄▪▐███▌▐▀ ▐█▌·
        ▀▀  █▪▀▀▀ ▀█▄▀▪ ▀█▄▀▪▀▀ █▪.▀▀▀ ▀▀▀·▀▀▀▀ ▀▀▀ · ▀▀▀ 
            
                        Protected and Safe
]]--

MoonTriggers = {}

MoonTriggers.AntiTrigger = true -- If true, the trigger will be prevented.

MoonTriggers.BlacklistedTriggers = { -- The triggers that will be prevented.
    "esx_qallejail:all",
    "lestervendita:pay"
}