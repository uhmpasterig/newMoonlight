--[[
        • ▌ ▄ ·.              ▐ ▄ ▄▄▌  ▪   ▄▄ •  ▄ .▄▄▄▄▄▄
        ·██ ▐███▪▪     ▪     •█▌▐███•  ██ ▐█ ▀ ▪██▪▐█•██  
        ▐█ ▌▐▌▐█· ▄█▀▄  ▄█▀▄ ▐█▐▐▌██▪  ▐█·▄█ ▀█▄██▀▐█ ▐█.▪
        ██ ██▌▐█▌▐█▌.▐▌▐█▌.▐▌██▐█▌▐█▌▐▌▐█▌▐█▄▪▐███▌▐▀ ▐█▌·
        ▀▀  █▪▀▀▀ ▀█▄▀▪ ▀█▄▀▪▀▀ █▪.▀▀▀ ▀▀▀·▀▀▀▀ ▀▀▀ · ▀▀▀ 
            
                        Protected and Safe
]]--


MoonVehicles = {}


MoonVehicles.AntiBLVehicle = true -- If true, the vehicle will be prevented.
MoonVehicles.BlacklistedVehicleban = true -- If true, the player will be banned.

-- ## Vehicle Blacklist ##
MoonVehicles.Blacklistedvehiclesl2 = { 
        "skylift",
        "valkyrie2",
        "airbus",
        "hunter",
        "rhino",
        "armytanker",
        "armytrailer",
        "armytrailer2",
        "baletrailer",
        "cablecar",
        "docktrailer",
        "freighttrailer",
        "graintrailer",
        "proptrailer",
        "raketrailer",
        "tr2",
        "tug",
        "tr3",
        "tr4",
        "trflat",
        "tvtrailer",
        "tanker",
        "tanker2",
        "trailerlarge",
        "trailerlogs"
}