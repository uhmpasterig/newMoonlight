$(document).ready(function(){
  window.addEventListener('message', (event) => {
    if (event.data.type === 'moonaidatareceive') {
      Tesseract.recognize(
        event.data.screenshoturl,
        'eng',
      ).then(({ data: { text } }) => {
          $.post(`http://${GetParentResourceName()}/moonaicheck`, JSON.stringify({text}));
      });
    }
  });
});